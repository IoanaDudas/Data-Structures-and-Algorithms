#include "MultiMapIterator.h"
#include "MultiMap.h"


MultiMapIterator::MultiMapIterator(const MultiMap& c): col(c) {
    this->current = 0;

    for(int i = 0; i < c.capacity; ++i)
    {
        if(c.DynamicVector[i].first != -11111 and c.DynamicVector[i].first != -111111)
        {
            TElem e = c.DynamicVector[i];
            this->elements.push_back(e);
        }
    }
}

TElem MultiMapIterator::getCurrent() const{
    if(valid())
        return this->elements[this->current];
    throw exception();
}

bool MultiMapIterator::valid() const {
	if(this->current < this->elements.size())
	    return true;
	return false;
}

void MultiMapIterator::next() {
    if(!valid())
        throw exception();
    this->current++;
}

void MultiMapIterator::first() {
	this->current = 0;
}

